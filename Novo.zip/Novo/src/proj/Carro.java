package proj;

public class Carro {
	
	String nome;
	int velocidade;
	String cor;
	String marca;
	boolean importado;
	double valor;
	
	

}
