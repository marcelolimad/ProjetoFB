package primeiro_classe_pack.constantes;

public class StatusAlu {

	public static String APROVADO = "Aprovado";
	public static String RECUPERACAO = "Recuperacao";
	public static String REPROVADO = "Reprovado";
	
	
}