package interfaces;

public interface Acesso {

	public boolean autenticar(String login, String senha);
	
	public boolean autenticar();
	
}
